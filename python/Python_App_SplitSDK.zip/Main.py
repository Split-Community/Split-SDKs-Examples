import logging
import MySplit
from time import sleep
import json

logging.basicConfig(filename='split.log',level=logging.DEBUG)

try:
    attributes=None
    attributes = dict()
    attributes['country'] = 'US'
    
    split = MySplit.MySplit('API KEY')
    treatment = split.getSplitTreatment('testing554', 'sample_feature', attributes)
    print("treatment: "+treatment)

# Getting treatment with Dynamic Configuration
    treatment = split.getSplitTreatmentWithConfig('testing111', 'sample_feature', attributes)
    print("treatment: "+treatment[0])    
    config=json.loads(treatment[1])
    
# Looping through configuration Keys
    for key in config:
        print("Key name: "+key+", value: "+config[key])
        
    
    if not split.sendTrack("testing554", "account", "conversion"):
        print("failed to send track event")
        split.destroy()
    sleep(60)
    
except Exception, e:
    print "Exception "+str(e.args)+", "+str(e)
    quit()

